package com.example.service

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

data class ParsedOrderInfo(
    val fare: Double,
    val distanceKm: Double,
    val durationMinutes: Int,
    val pickupLocation: String,
    val deliveryLocation: String,
    val rawText: String
)

object OcrParser {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun recognizeTextFromBitmap(bitmap: Bitmap): String = suspendCoroutine { continuation ->
        val image = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(image)
            .addOnSuccessListener { visionText ->
                continuation.resume(visionText.text)
            }
            .addOnFailureListener { e ->
                continuation.resume("خطأ في قراءة النص: ${e.localizedMessage}")
            }
    }

    fun parseOrderText(text: String): ParsedOrderInfo {
        var fare = 5000.0 // Default sample IQD
        var distance = 4.5 // Default km
        var duration = 15 // Default minutes
        var pickup = "مطعم الشطرة"
        var delivery = "شارع الرشيد"

        val lines = text.split("\n")
        val fareRegex = Regex("([\\d,]+)\\s*(د\\.ع|دينار|IQD)?", RegexOption.IGNORE_CASE)
        val distanceRegex = Regex("([\\d.]+)\\s*(كم|km|كيلومتر)", RegexOption.IGNORE_CASE)
        val durationRegex = Regex("([\\d]+)\\s*(دقيقة|دقيقتين|دقائق|min)", RegexOption.IGNORE_CASE)

        for (line in lines) {
            val lower = line.lowercase()
            if (lower.contains("د.ع") || lower.contains("دينار") || lower.contains("السعر") || lower.contains("الأجرة")) {
                val match = fareRegex.find(line)
                match?.groups?.get(1)?.value?.let { numStr ->
                    val clean = numStr.replace(",", "").toDoubleOrNull()
                    if (clean != null && clean > 500) {
                        fare = clean
                    }
                }
            }

            if (lower.contains("كم") || lower.contains("km") || lower.contains("المسافة")) {
                val match = distanceRegex.find(line)
                match?.groups?.get(1)?.value?.let { numStr ->
                    val clean = numStr.toDoubleOrNull()
                    if (clean != null && clean > 0) {
                        distance = clean
                    }
                }
            }

            if (lower.contains("دقيقة") || lower.contains("دقائق") || lower.contains("min") || lower.contains("الوقت")) {
                val match = durationRegex.find(line)
                match?.groups?.get(1)?.value?.let { numStr ->
                    val clean = numStr.toIntOrNull()
                    if (clean != null && clean > 0) {
                        duration = clean
                    }
                }
            }

            if (lower.contains("من:") || lower.contains("استلام") || lower.contains("pickup")) {
                pickup = line.replace("من:", "").replace("استلام:", "").trim()
                if (pickup.isEmpty()) pickup = "نقطة استلام الطلب"
            }

            if (lower.contains("إلى:") || lower.contains("تسليم") || lower.contains("delivery")) {
                delivery = line.replace("إلى:", "").replace("تسليم:", "").trim()
                if (delivery.isEmpty()) delivery = "نقطة تسليم العميل"
            }
        }

        if (fare == 5000.0) {
            val allNumbers = Regex("([\\d,]{4,})").findAll(text)
            for (match in allNumbers) {
                val valNum = match.value.replace(",", "").toDoubleOrNull()
                if (valNum != null && valNum in 1000.0..100000.0) {
                    fare = valNum
                    break
                }
            }
        }

        if (distance == 4.5) {
            val distMatch = Regex("([\\d.]+)\\s*(كم|km)").find(text)
            distMatch?.groups?.get(1)?.value?.toDoubleOrNull()?.let {
                distance = it
            }
        }

        return ParsedOrderInfo(
            fare = fare,
            distanceKm = distance,
            durationMinutes = duration,
            pickupLocation = if (pickup.length > 2) pickup else "موقع الاستلام",
            deliveryLocation = if (delivery.length > 2) delivery else "موقع التسليم",
            rawText = text
        )
    }
}

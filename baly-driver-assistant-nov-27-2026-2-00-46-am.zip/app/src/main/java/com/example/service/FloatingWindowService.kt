package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.AppDatabase
import com.example.data.DriverPreferences
import com.example.domain.CalculationEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class FloatingWindowService : Service() {

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_UPDATE_ORDER = "ACTION_UPDATE_ORDER"
        
        var currentFare: Double = 6500.0
        var currentDistance: Double = 5.2
        var currentDuration: Int = 18
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(true)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                startForegroundServiceWithNotification()
                showFloatingWindow()
            }
        }
        return START_STICKY
    }

    private fun startForegroundServiceWithNotification() {
        val channelId = "baly_assistant_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "مساعد بلي - الخدمة العائمة",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("مساعد سائق بلي يعمل في الخلفية")
            .setContentText("انقر لفتح لوحة التحكم والنافذة العائمة")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pendingIntent)
            .build()

        startForeground(1001, notification)
    }

    private fun showFloatingWindow() {
        if (floatingView != null) return

        val layoutParamsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutParamsType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 200
        }

        // Inflate floating layout programmatically to ensure no xml bloating
        val contextThemeWrapper = android.view.ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault_Light)
        val view = LayoutInflater.from(contextThemeWrapper).inflate(
            android.R.layout.activity_list_item, null
        ) // We can construct custom programmatic layout or simple card view

        // Let's create a custom programmatic FrameLayout/Card for maximum styling control
        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.parseColor("#E6121E26"))
            setPadding(32, 32, 32, 32)
            elevation = 16f
        }

        val titleView = TextView(this).apply {
            text = "⚡ مساعد بلي الذكي"
            setTextColor(android.graphics.Color.WHITE)
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
        }

        val priceView = TextView(this).apply {
            text = "الأجرة: ${currentFare.toInt()} د.ع | ${currentDistance} كم"
            setTextColor(android.graphics.Color.GREEN)
            textSize = 13f
        }

        val profitView = TextView(this).apply {
            text = "صافي الربح: جاري الحساب..."
            setTextColor(android.graphics.Color.YELLOW)
            textSize = 13f
        }

        val recommendationView = TextView(this).apply {
            text = "التوصية: جاري التحليل..."
            setTextColor(android.graphics.Color.CYAN)
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
        }

        val closeBtn = Button(this).apply {
            text = "إخفاء"
            textSize = 11f
            minHeight = 0
            minimumHeight = 0
            setOnClickListener {
                stopSelf()
            }
        }

        container.addView(titleView)
        container.addView(priceView)
        container.addView(profitView)
        container.addView(recommendationView)
        container.addView(closeBtn)

        floatingView = container

        // Calculate initial values
        serviceScope.launch {
            val prefs = DriverPreferences(applicationContext).settingsFlow.first()
            val analysis = CalculationEngine.analyzeOrder(currentFare, currentDistance, currentDuration, prefs)
            profitView.text = "صافي الربح: ${analysis.netProfit.toInt()} د.ع"
            recommendationView.text = "التوصية: ${analysis.recommendationTextArabic}"
            recommendationView.setTextColor(
                when (analysis.recommendation) {
                    com.example.domain.RecommendationType.ACCEPT -> android.graphics.Color.GREEN
                    com.example.domain.RecommendationType.CONDITIONAL -> android.graphics.Color.YELLOW
                    com.example.domain.RecommendationType.REJECT -> android.graphics.Color.RED
                }
            )
        }

        // Touch listener for dragging
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager?.updateViewLayout(floatingView, params)
                    true
                }
                else -> false
            }
        }

        try {
            windowManager?.addView(floatingView, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        if (floatingView != null) {
            try {
                windowManager?.removeView(floatingView)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            floatingView = null
        }
    }
}

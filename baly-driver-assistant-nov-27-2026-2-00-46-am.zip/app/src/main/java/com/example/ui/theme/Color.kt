package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BalyRed = Color(0xFFE6121E)
val BalyRedDark = Color(0xFFB30B14)
val BalyDarkBg = Color(0xFF12161F)
val BalySurfaceDark = Color(0xFF1A202C)
val BalyCardDark = Color(0xFF242C3D)

val PrimaryLight = Color(0xFFE6121E)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFFFDAD6)
val OnPrimaryContainerLight = Color(0xFF410002)

val BackgroundLight = Color(0xFFF8F9FA)
val SurfaceLight = Color(0xFFFFFFFF)
val CardLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF1A1C1E)

val SuccessGreen = Color(0xFF10B981)
val WarningYellow = Color(0xFFF59E0B)
val DangerRed = Color(0xFFEF4444)

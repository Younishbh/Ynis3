package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DriverSettings
import com.example.ui.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val currentSettings by viewModel.settings.collectAsState()

    var bikeType by remember(currentSettings) { mutableStateOf(currentSettings.bikeType) }
    var engineCapacity by remember(currentSettings) { mutableStateOf(currentSettings.engineCapacity.toString()) }
    var fuelConsumption by remember(currentSettings) { mutableStateOf(currentSettings.fuelConsumptionPer100Km.toString()) }
    var fuelPrice by remember(currentSettings) { mutableStateOf(currentSettings.fuelPricePerLiter.toString()) }
    var opExpenses by remember(currentSettings) { mutableStateOf(currentSettings.operationalExpensesPerKm.toString()) }
    var minProfit by remember(currentSettings) { mutableStateOf(currentSettings.minAcceptedProfit.toString()) }
    var minProfitKm by remember(currentSettings) { mutableStateOf(currentSettings.minProfitPerKm.toString()) }
    var minProfitHour by remember(currentSettings) { mutableStateOf(currentSettings.minProfitPerHour.toString()) }
    var maxDistance by remember(currentSettings) { mutableStateOf(currentSettings.maxDistanceKm.toString()) }

    var showSavedMessage by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("إعدادات السيارة ومعايير الأرباح") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("معلومات السيارة والوقود", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)

                    OutlinedTextField(
                        value = bikeType,
                        onValueChange = { bikeType = it },
                        label = { Text("نوع السيارة (مثل النترا، أوبتيما، سوناتا)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = engineCapacity,
                            onValueChange = { engineCapacity = it },
                            label = { Text("سعة محرك السيارة (CC)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = fuelConsumption,
                            onValueChange = { fuelConsumption = it },
                            label = { Text("استهلاك الوقود (لتر/100كم)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    OutlinedTextField(
                        value = fuelPrice,
                        onValueChange = { fuelPrice = it },
                        label = { Text("سعر لتر البنزين (دينار عراقي)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = opExpenses,
                        onValueChange = { opExpenses = it },
                        label = { Text("المصاريف التشغيلية للسيارة (د.ع / كم) (صيانة، زيت، إطارات، استهلاك)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("معايير التوصيات الذكية لطلبات التوصيل", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)

                    OutlinedTextField(
                        value = minProfit,
                        onValueChange = { minProfit = it },
                        label = { Text("الحد الأدنى لصافي الربح المقبول للطلب (د.ع)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = minProfitKm,
                            onValueChange = { minProfitKm = it },
                            label = { Text("الحد الأدنى للربح/كم (د.ع)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = minProfitHour,
                            onValueChange = { minProfitHour = it },
                            label = { Text("الحد الأدنى للربح/ساعة (د.ع)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    OutlinedTextField(
                        value = maxDistance,
                        onValueChange = { maxDistance = it },
                        label = { Text("الحد الأقصى لمسافة الطلب (كم)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }

            Button(
                onClick = {
                    val newSettings = DriverSettings(
                        bikeType = bikeType,
                        engineCapacity = engineCapacity.toDoubleOrNull() ?: 2000.0,
                        fuelConsumptionPer100Km = fuelConsumption.toDoubleOrNull() ?: 9.0,
                        fuelPricePerLiter = fuelPrice.toDoubleOrNull() ?: 1000.0,
                        operationalExpensesPerKm = opExpenses.toDoubleOrNull() ?: 250.0,
                        minAcceptedProfit = minProfit.toDoubleOrNull() ?: 6000.0,
                        minProfitPerKm = minProfitKm.toDoubleOrNull() ?: 750.0,
                        minProfitPerHour = minProfitHour.toDoubleOrNull() ?: 12000.0,
                        maxDistanceKm = maxDistance.toDoubleOrNull() ?: 20.0
                    )
                    viewModel.updateSettings(newSettings)
                    showSavedMessage = true
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("حفظ إعدادات السيارة", fontWeight = FontWeight.Bold)
            }

            if (showSavedMessage) {
                Snackbar(
                    action = {
                        TextButton(onClick = { showSavedMessage = false }) {
                            Text("تم")
                        }
                    }
                ) {
                    Text("تم حفظ إعدادات السيارة بنجاح!")
                }
            }
        }
    }
}

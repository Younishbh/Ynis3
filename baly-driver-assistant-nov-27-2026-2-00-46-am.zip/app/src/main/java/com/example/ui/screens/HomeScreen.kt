package com.example.ui.screens

import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.OrderEntity
import com.example.service.FloatingWindowService
import com.example.ui.MainViewModel
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningYellow
import com.example.ui.theme.DangerRed

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToAnalyzer: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val context = LocalContext.current
    val orders by viewModel.orders.collectAsState(initial = emptyList())
    val settings by viewModel.settings.collectAsState()

    var isServiceRunning by remember { mutableStateOf(false) }

    val todayOrders = orders.filter { 
        val diff = System.currentTimeMillis() - it.timestamp
        diff < 24 * 60 * 60 * 1000L
    }
    val totalNetProfit = todayOrders.sumOf { it.netProfit }
    val totalRevenue = todayOrders.sumOf { it.fare }
    val totalFuelCost = todayOrders.sumOf { it.fuelCost }
    val acceptedCount = todayOrders.count { it.driverAction == "ACCEPTED" }
    val rejectedCount = todayOrders.count { it.driverAction == "REJECTED" }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مساعد سائق بلي الذكي", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "الإعدادات")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(if (isServiceRunning) SuccessGreen else Color.Gray)
                                )
                                Text(
                                    text = if (isServiceRunning) "النافذة العائمة نشطة" else "النافذة العائمة متوقفة",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                            }
                            Switch(
                                checked = isServiceRunning,
                                onCheckedChange = { checked ->
                                    if (checked) {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                                            val intent = Intent(
                                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                                android.net.Uri.parse("package:${context.packageName}")
                                            )
                                            context.startActivity(intent)
                                        } else {
                                            val intent = Intent(context, FloatingWindowService::class.java).apply {
                                                action = FloatingWindowService.ACTION_START
                                            }
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                                context.startForegroundService(intent)
                                            } else {
                                                context.startService(intent)
                                            }
                                            isServiceRunning = true
                                        }
                                    } else {
                                        val intent = Intent(context, FloatingWindowService::class.java).apply {
                                            action = FloatingWindowService.ACTION_STOP
                                        }
                                        context.startService(intent)
                                        isServiceRunning = false
                                    }
                                }
                            )
                        }
                        Text(
                            text = "تظهر هذه النافذة فوق تطبيق بلي لتعرض لك تحليل الأجرة والربح الفعلي فور وصول الطلب.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onNavigateToAnalyzer,
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Calculate, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تحليـل طلب جديد", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    OutlinedButton(
                        onClick = onNavigateToHistory,
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.History, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("الإحصائيات والأرباح", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "ملخص اليوم",
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("صافي الأرباح", color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f), fontSize = 12.sp)
                                Text("${totalNetProfit.toInt()} د.ع", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            }
                            Column {
                                Text("الإيرادات", color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f), fontSize = 12.sp)
                                Text("${totalRevenue.toInt()} د.ع", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            }
                            Column {
                                Text("تكلفة الوقود", color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f), fontSize = 12.sp)
                                Text("${totalFuelCost.toInt()} د.ع", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            }
                        }
                        Divider(color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.2f))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("الطلبات المقبولة: $acceptedCount", color = MaterialTheme.colorScheme.onPrimary, fontSize = 13.sp)
                            Text("الطلبات المرفوضة: $rejectedCount", color = MaterialTheme.colorScheme.onPrimary, fontSize = 13.sp)
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("آخر الطلبات المحللة", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    TextButton(onClick = onNavigateToHistory) {
                        Text("عرض الكل")
                    }
                }
            }

            if (orders.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "لا توجد طلبات محللة حتى الآن.\nاضغط على تحليل طلب جديد للبدء.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                items(orders.take(5)) { order ->
                    OrderCard(order = order, onActionSelected = { action ->
                        viewModel.updateDriverAction(order.id, action)
                    })
                }
            }
        }
    }
}

@Composable
fun OrderCard(order: OrderEntity, onActionSelected: (String) -> Unit) {
    val recommendationColor = when (order.recommendation) {
        "ACCEPT" -> SuccessGreen
        "CONDITIONAL" -> WarningYellow
        else -> DangerRed
    }

    val recommendationLabel = when (order.recommendation) {
        "ACCEPT" -> "قبول الطلب"
        "CONDITIONAL" -> "طلب متوسط"
        else -> "رفض الطلب"
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${order.fare.toInt()} د.ع",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = recommendationColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = recommendationLabel,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        color = recommendationColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("المسافة: ${order.distanceKm} كم", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("الوقت: ${order.durationMinutes} دقيقة", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("صافي الربح: ${order.netProfit.toInt()} د.ع", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
            }

            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الربح/كم: ${order.profitPerKm.toInt()} د.ع",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { onActionSelected("REJECTED") },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text("رفض", fontSize = 12.sp)
                    }
                    Button(
                        onClick = { onActionSelected("ACCEPTED") },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text("قبول", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

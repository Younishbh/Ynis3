package com.example.ui.screens

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.OrderAnalysisResult
import com.example.service.OcrParser
import com.example.ui.MainViewModel
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningYellow
import com.example.ui.theme.DangerRed
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderAnalyzerScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by viewModel.settings.collectAsState()

    var fareText by remember { mutableStateOf("6500") }
    var distanceText by remember { mutableStateOf("4.5") }
    var durationText by remember { mutableStateOf("15") }
    var pickupText by remember { mutableStateOf("مطعم البركة - الكرادة") }
    var deliveryText by remember { mutableStateOf("شارع فلسطين - قرب النادي") }

    var analysisResult by remember { mutableStateOf<OrderAnalysisResult?>(null) }
    var isOcrLoading by remember { mutableStateOf(false) }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            scope.launch {
                isOcrLoading = true
                try {
                    val inputStream = context.contentResolver.openInputStream(uri)
                    val bitmap = BitmapFactory.decodeStream(inputStream)
                    if (bitmap != null) {
                        val rawText = OcrParser.recognizeTextFromBitmap(bitmap)
                        val parsed = OcrParser.parseOrderText(rawText)
                        fareText = parsed.fare.toInt().toString()
                        distanceText = parsed.distanceKm.toString()
                        durationText = parsed.durationMinutes.toString()
                        pickupText = parsed.pickupLocation
                        deliveryText = parsed.deliveryLocation

                        val result = viewModel.analyzeAndSaveOrder(
                            parsed.fare, parsed.distanceKm, parsed.durationMinutes,
                            parsed.pickupLocation, parsed.deliveryLocation, "PENDING"
                        )
                        analysisResult = result
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                } finally {
                    isOcrLoading = false
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("محلل طلبات بلي الذكي") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.CameraAlt, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                    Text(
                        text = "قراءة الطلب تلقائياً من لقطة شاشة بلي (OCR)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "اختر صورة الطلب من معرض الصور لاستخراج الأجرة والمحطة والمسافة بالذكاء الاصطناعي المحلي.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Button(
                        onClick = { imagePickerLauncher.launch("image/*") },
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        if (isOcrLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = MaterialTheme.colorScheme.onPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Text("اختر لقطة شاشة الطلب", fontSize = 14.sp)
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("أدخل تفاصيل الطلب يدوياً", fontWeight = FontWeight.Bold, fontSize = 16.sp)

                    OutlinedTextField(
                        value = fareText,
                        onValueChange = { fareText = it },
                        label = { Text("أجرة التوصيل (دينار عراقي)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = distanceText,
                            onValueChange = { distanceText = it },
                            label = { Text("المسافة (كم)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = durationText,
                            onValueChange = { durationText = it },
                            label = { Text("الوقت (دقيقة)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    OutlinedTextField(
                        value = pickupText,
                        onValueChange = { pickupText = it },
                        label = { Text("موقع الاستلام (المطعم)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = deliveryText,
                        onValueChange = { deliveryText = it },
                        label = { Text("موقع التسليم (العميل)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Button(
                        onClick = {
                            val f = fareText.toDoubleOrNull() ?: 5000.0
                            val d = distanceText.toDoubleOrNull() ?: 4.0
                            val t = durationText.toIntOrNull() ?: 15
                            val res = viewModel.analyzeAndSaveOrder(f, d, t, pickupText, deliveryText, "PENDING")
                            analysisResult = res
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Icon(Icons.Default.Analytics, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تحليل الربحية والتوصية", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }

            analysisResult?.let { result ->
                val recColor = when (result.recommendation) {
                    com.example.domain.RecommendationType.ACCEPT -> SuccessGreen
                    com.example.domain.RecommendationType.CONDITIONAL -> WarningYellow
                    com.example.domain.RecommendationType.REJECT -> DangerRed
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("نتيجة التحليل الذكي", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = recColor.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = result.recommendationTextArabic,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    color = recColor,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }

                        Divider()

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("أجرة التوصيل:")
                            Text("${result.fare.toInt()} د.ع", fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("تكلفة الوقود (${settings.fuelConsumptionPer100Km}لتر/100كم):")
                            Text("-${result.fuelCost.toInt()} د.ع", color = DangerRed)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("المصاريف التشغيلية (${settings.operationalExpensesPerKm} د.ع/كم):")
                            Text("-${result.operationalCost.toInt()} د.ع", color = DangerRed)
                        }

                        Divider()

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("صافي الربح الحقيقي:", fontWeight = FontWeight.Bold)
                            Text("${result.netProfit.toInt()} د.ع", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = SuccessGreen)
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الربح لكل كيلومتر:")
                            Text("${result.profitPerKm.toInt()} د.ع / كم", fontWeight = FontWeight.Bold)
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الربح لكل ساعة:")
                            Text("${result.profitPerHour.toInt()} د.ع / ساعة", fontWeight = FontWeight.Bold)
                        }

                        Divider()

                        Text("الأسباب والتفاصيل:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        result.reasons.forEach { reason ->
                            Text("• $reason", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.DangerRed

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrdersHistoryScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val orders by viewModel.orders.collectAsState(initial = emptyList())

    val totalRevenue = orders.sumOf { it.fare }
    val totalFuel = orders.sumOf { it.fuelCost }
    val totalNetProfit = orders.sumOf { it.netProfit }
    val avgProfit = if (orders.isNotEmpty()) totalNetProfit / orders.size else 0.0
    val avgPerKm = if (orders.isNotEmpty()) orders.sumOf { it.profitPerKm } / orders.size else 0.0

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("سجل الطلبات والإحصائيات الشاملة") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    if (orders.isNotEmpty()) {
                        IconButton(onClick = { viewModel.clearAllOrders() }) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = "مسح السجل")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("ملخص الأداء العام (${orders.size} طلب)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("إجمالي الإيرادات", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${totalRevenue.toInt()} د.ع", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            Column {
                                Text("إجمالي تكلفة الوقود", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${totalFuel.toInt()} د.ع", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DangerRed)
                            }
                            Column {
                                Text("صافي الأرباح", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${totalNetProfit.toInt()} د.ع", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = SuccessGreen)
                            }
                        }

                        Divider()

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("متوسط ربح الطلب الواحد:", fontSize = 13.sp)
                            Text("${avgProfit.toInt()} د.ع", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("متوسط الربح لكل كم:", fontSize = 13.sp)
                            Text("${avgPerKm.toInt()} د.ع / كم", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }

            item {
                Text("تفاصيل الطلبات السابقة", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            if (orders.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("لا توجد طلبات محفوظة في السجل.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                items(orders) { order ->
                    OrderCard(order = order, onActionSelected = { action ->
                        viewModel.updateDriverAction(order.id, action)
                    })
                }
            }
        }
    }
}

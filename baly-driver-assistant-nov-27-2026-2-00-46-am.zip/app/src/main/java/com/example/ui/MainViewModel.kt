package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.DriverPreferences
import com.example.data.DriverSettings
import com.example.data.OrderEntity
import com.example.domain.CalculationEngine
import com.example.domain.OrderAnalysisResult
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val orderDao = database.orderDao()
    private val driverPreferences = DriverPreferences(application)

    val settings: StateFlow<DriverSettings> = driverPreferences.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DriverSettings()
    )

    val orders: StateFlow<List<OrderEntity>> = orderDao.getAllOrders().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun updateSettings(newSettings: DriverSettings) {
        viewModelScope.launch {
            driverPreferences.updateSettings(newSettings)
        }
    }

    fun analyzeAndSaveOrder(
        fare: Double,
        distanceKm: Double,
        durationMinutes: Int,
        pickup: String,
        delivery: String,
        action: String = "PENDING"
    ): OrderAnalysisResult {
        val currentSettings = settings.value
        val analysis = CalculationEngine.analyzeOrder(fare, distanceKm, durationMinutes, currentSettings)

        viewModelScope.launch {
            val entity = OrderEntity(
                fare = fare,
                distanceKm = distanceKm,
                durationMinutes = durationMinutes,
                pickupLocation = pickup,
                deliveryLocation = delivery,
                fuelCost = analysis.fuelCost,
                netProfit = analysis.netProfit,
                profitPerKm = analysis.profitPerKm,
                profitPerHour = analysis.profitPerHour,
                recommendation = analysis.recommendation.name,
                driverAction = action
            )
            orderDao.insertOrder(entity)
        }

        return analysis
    }

    fun updateDriverAction(orderId: Long, action: String) {
        viewModelScope.launch {
            orderDao.updateDriverAction(orderId, action)
        }
    }

    fun deleteOrder(order: OrderEntity) {
        viewModelScope.launch {
            orderDao.deleteOrder(order)
        }
    }

    fun clearAllOrders() {
        viewModelScope.launch {
            orderDao.clearAll()
        }
    }
}

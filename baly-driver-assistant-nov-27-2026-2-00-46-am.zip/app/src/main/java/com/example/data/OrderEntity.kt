package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val fare: Double, // in IQD
    val distanceKm: Double,
    val durationMinutes: Int,
    val pickupLocation: String,
    val deliveryLocation: String,
    val fuelCost: Double,
    val netProfit: Double,
    val profitPerKm: Double,
    val profitPerHour: Double,
    val recommendation: String, // "ACCEPT", "CONDITIONAL", "REJECT"
    val timestamp: Long = System.currentTimeMillis(),
    val driverAction: String = "PENDING" // "ACCEPTED", "REJECTED", "PENDING"
)

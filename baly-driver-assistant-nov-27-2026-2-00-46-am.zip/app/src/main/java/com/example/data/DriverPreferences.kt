package com.example.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "driver_preferences")

data class DriverSettings(
    val bikeType: String = "سيارة اقتصادية (مثل النترا / أوبتيما - 2000cc)",
    val engineCapacity: Double = 2000.0,
    val fuelConsumptionPer100Km: Double = 9.0, // Liters per 100km for car
    val fuelPricePerLiter: Double = 1000.0, // IQD
    val operationalExpensesPerKm: Double = 250.0, // IQD per km (car maintenance, oil, tires, depreciation)
    val minAcceptedProfit: Double = 6000.0, // IQD
    val minProfitPerKm: Double = 750.0, // IQD / km
    val minProfitPerHour: Double = 12000.0, // IQD / hour
    val maxDistanceKm: Double = 20.0 // km
)

class DriverPreferences(private val context: Context) {
    companion object {
        val BIKE_TYPE = stringPreferencesKey("bike_type")
        val ENGINE_CAPACITY = doublePreferencesKey("engine_capacity")
        val FUEL_CONSUMPTION = doublePreferencesKey("fuel_consumption")
        val FUEL_PRICE = doublePreferencesKey("fuel_price")
        val OP_EXPENSES = doublePreferencesKey("op_expenses")
        val MIN_PROFIT = doublePreferencesKey("min_profit")
        val MIN_PROFIT_KM = doublePreferencesKey("min_profit_km")
        val MIN_PROFIT_HOUR = doublePreferencesKey("min_profit_hour")
        val MAX_DISTANCE = doublePreferencesKey("max_distance")
    }

    val settingsFlow: Flow<DriverSettings> = context.dataStore.data.map { preferences ->
        DriverSettings(
            bikeType = preferences[BIKE_TYPE] ?: "سيارة اقتصادية (مثل النترا / أوبتيما - 2000cc)",
            engineCapacity = preferences[ENGINE_CAPACITY] ?: 2000.0,
            fuelConsumptionPer100Km = preferences[FUEL_CONSUMPTION] ?: 9.0,
            fuelPricePerLiter = preferences[FUEL_PRICE] ?: 1000.0,
            operationalExpensesPerKm = preferences[OP_EXPENSES] ?: 250.0,
            minAcceptedProfit = preferences[MIN_PROFIT] ?: 6000.0,
            minProfitPerKm = preferences[MIN_PROFIT_KM] ?: 750.0,
            minProfitPerHour = preferences[MIN_PROFIT_HOUR] ?: 12000.0,
            maxDistanceKm = preferences[MAX_DISTANCE] ?: 20.0
        )
    }

    suspend fun updateSettings(settings: DriverSettings) {
        context.dataStore.edit { preferences ->
            preferences[BIKE_TYPE] = settings.bikeType
            preferences[ENGINE_CAPACITY] = settings.engineCapacity
            preferences[FUEL_CONSUMPTION] = settings.fuelConsumptionPer100Km
            preferences[FUEL_PRICE] = settings.fuelPricePerLiter
            preferences[OP_EXPENSES] = settings.operationalExpensesPerKm
            preferences[MIN_PROFIT] = settings.minAcceptedProfit
            preferences[MIN_PROFIT_KM] = settings.minProfitPerKm
            preferences[MIN_PROFIT_HOUR] = settings.minProfitPerHour
            preferences[MAX_DISTANCE] = settings.maxDistanceKm
        }
    }
}

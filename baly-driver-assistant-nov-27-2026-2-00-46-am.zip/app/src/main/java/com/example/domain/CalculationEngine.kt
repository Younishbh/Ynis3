package com.example.domain

import com.example.data.DriverSettings

data class OrderAnalysisResult(
    val fare: Double,
    val distanceKm: Double,
    val durationMinutes: Int,
    val fuelCost: Double,
    val operationalCost: Double,
    val netProfit: Double,
    val profitPerKm: Double,
    val profitPerHour: Double,
    val recommendation: RecommendationType,
    val recommendationTextArabic: String,
    val reasons: List<String>
)

enum class RecommendationType {
    ACCEPT, CONDITIONAL, REJECT
}

object CalculationEngine {

    fun analyzeOrder(
        fare: Double,
        distanceKm: Double,
        durationMinutes: Int,
        settings: DriverSettings
    ): OrderAnalysisResult {
        val safeDistance = if (distanceKm <= 0.0) 1.0 else distanceKm
        val safeDuration = if (durationMinutes <= 0) 15 else durationMinutes

        // Fuel Cost calculation: Distance * (Liters per 100km / 100) * Price per liter
        val fuelCost = safeDistance * (settings.fuelConsumptionPer100Km / 100.0) * settings.fuelPricePerLiter

        // Operational Cost calculation: Distance * Operational expenses per km
        val operationalCost = safeDistance * settings.operationalExpensesPerKm

        // Net Profit = Fare - Fuel Cost - Operational Cost
        val netProfit = fare - fuelCost - operationalCost

        // Profit per Km = Net Profit / Distance
        val profitPerKm = netProfit / safeDistance

        // Profit per Hour = Net Profit / (Duration in hours)
        val hours = safeDuration / 60.0
        val profitPerHour = if (hours > 0) netProfit / hours else netProfit

        val reasons = mutableListOf<String>()
        var recommendation = RecommendationType.CONDITIONAL

        // Check criteria
        val isProfitGood = netProfit >= settings.minAcceptedProfit
        val isPerKmGood = profitPerKm >= settings.minProfitPerKm
        val isPerHourGood = profitPerHour >= settings.minProfitPerHour
        val isDistanceGood = safeDistance <= settings.maxDistanceKm

        if (!isDistanceGood) {
            reasons.add("المسافة (${String.format("%.1f", safeDistance)} كم) تتجاوز الحد الأقصى (${settings.maxDistanceKm} كم)")
        }
        if (!isProfitGood) {
            reasons.add("صافي الربح (${String.format("%.0f", netProfit)} د.ع) أقل من الحد الأدنى (${settings.minAcceptedProfit} د.ع)")
        }
        if (!isPerKmGood) {
            reasons.add("الربح لكل كيلومتر (${String.format("%.0f", profitPerKm)} د.ع) منخفض")
        }
        if (!isPerHourGood) {
            reasons.add("الربح لكل ساعة (${String.format("%.0f", profitPerHour)} د.ع) منخفض")
        }

        if (isProfitGood && isPerKmGood && isPerHourGood && isDistanceGood) {
            recommendation = RecommendationType.ACCEPT
            reasons.add(0, "الطلب ممتاز ومربح جداً! جميع المعايير مطابقة.")
        } else if (netProfit < (settings.minAcceptedProfit * 0.5) || profitPerKm < (settings.minProfitPerKm * 0.4) || !isDistanceGood) {
            recommendation = RecommendationType.REJECT
            reasons.add(0, "الطلب غير مربح أو مسافته بعيدة جداً، يُنصح بالرفض.")
        } else {
            recommendation = RecommendationType.CONDITIONAL
            reasons.add(0, "طلب متوسط الربح، القرار يعود لك.")
        }

        val recommendationText = when (recommendation) {
            RecommendationType.ACCEPT -> "قبول الطلب"
            RecommendationType.CONDITIONAL -> "طلب متوسط، القرار للسائق"
            RecommendationType.REJECT -> "رفض الطلب"
        }

        return OrderAnalysisResult(
            fare = fare,
            distanceKm = safeDistance,
            durationMinutes = safeDuration,
            fuelCost = fuelCost,
            operationalCost = operationalCost,
            netProfit = netProfit,
            profitPerKm = profitPerKm,
            profitPerHour = profitPerHour,
            recommendation = recommendation,
            recommendationTextArabic = recommendationText,
            reasons = reasons
        )
    }
}
